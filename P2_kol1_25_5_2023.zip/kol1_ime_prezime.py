from countries import countries

print(countries)
