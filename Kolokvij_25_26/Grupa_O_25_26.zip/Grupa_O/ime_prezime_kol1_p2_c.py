'''
Grupa O

U datoteci attendance.py nalazi se lista dolazaka studenata.
Svaki dolazak predstavljen je kao string oblika:

    ime;status

Primjer:
    Ana;prisutan

Učitavanje podataka:
    Učitaj listu attendance iz datoteke attendance.py.

Provjera zapisa:
    Ispravan zapis mora imati:
        ime koje počinje velikim slovom
        status koji može biti prisutan ili odsutan

    Ispravnost zapisa provjeri pomoću regularnog izraza.

Obrada podataka:
    Izdvoji samo ispravne zapise.

    Prebroji koliko je studenata prisutno, a koliko odsutno.

Ispis i zapis rezultata:
    Na ekran ispiši:
        Broj svih zapisa
        Broj ispravnih zapisa
        Broj prisutnih studenata
        Broj odsutnih studenata

    Iste rezultate upiši u tekstualnu datoteku izvjestaj_dolasci.txt.

Napomena:
    Program mora raditi nad podacima učitanim iz datoteke attendance.py.
    Podatke nije dozvoljeno ručno prepisivati u rješenje.
'''
