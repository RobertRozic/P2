students = [
    {"indeks": "P2-001", "ime": "Ana", "prezime": "Anic", "bodovi": 8},
    {"indeks": "P2-002", "ime": "Marko", "prezime": "Markovic", "bodovi": 5},
    {"indeks": "P2-003", "ime": "Lejla", "prezime": "Basic", "bodovi": 9},
    {"indeks": "P-004", "ime": "Ivan", "prezime": "Ilic", "bodovi": 7},
    {"indeks": "P2-005", "ime": "Sara", "prezime": "Saric", "bodovi": 4},
    {"indeks": "P2-006", "ime": "Amar", "prezime": "Amic", "bodovi": 6},
    {"indeks": "P2007", "ime": "Ema", "prezime": "Emic", "bodovi": 10},
    {"indeks": "P2-008", "ime": "Mia", "prezime": "Matic", "bodovi": 3},
    {"indeks": "P2-009", "ime": "Niko", "prezime": "Nikolic", "bodovi": 7},
    {"indeks": "P2-10", "ime": "Tara", "prezime": "Taric", "bodovi": 8}
]
