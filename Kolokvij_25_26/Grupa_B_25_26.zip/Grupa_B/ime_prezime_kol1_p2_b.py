'''
Grupa B

U datoteci students.py nalazi se lista studenata.
Svaki student predstavljen je kao dictionary oblika:

{
    "indeks": "P2-001",
    "ime": "Ana",
    "prezime": "Anic",
    "bodovi": 8
}

Učitavanje podataka:
    Učitaj listu students iz datoteke students.py.

Provjera indeksa:
    Indeks mora biti u obliku P2-XXX, gdje su X znamenke.
    Primjer ispravnog indeksa: P2-001
    Primjer neispravnog indeksa: P-001, P2-1, P2001

    Ispravnost indeksa provjeri pomoću regularnog izraza.

Obrada podataka:
    Izdvoji samo studente koji imaju ispravan indeks.

    Za svakog ispravnog studenta provjeri da li je položio.
    Student je položio ako ima 6 ili više bodova.

    Napravi rječnik statusi u kojem su ključevi:
        "polozio"
        "nije polozio"

    Vrijednosti u rječniku predstavljaju broj studenata za svaki status.

    Napravi set prezimena studenata koji su položili.

Ispis i zapis rezultata:
    Na ekran ispiši:
        Broj svih studenata
        Broj studenata s ispravnim indeksom
        Rječnik statusi
        Set prezimena studenata koji su položili

    Iste rezultate upiši u tekstualnu datoteku rezultati_studenata.txt.
'''
