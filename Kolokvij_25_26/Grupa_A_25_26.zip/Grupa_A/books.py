books = [
    ("BK-101", "Mali princ", "Antoine de Saint-Exupery", 1943),
    ("BK-102", "Na Drini cuprija", "Ivo Andric", 1945),
    ("BK-103", "Prokleta avlija", "Ivo Andric", 1954),
    ("B-104", "Dervis i smrt", "Mesa Selimovic", 1966),
    ("BK-105", "Tvrdjava", "Mesa Selimovic", 1970),
    ("BK-106", "Stranac", "Albert Camus", 1942),
    ("BK10", "Proces", "Franz Kafka", 1925),
    ("BK-107", "Zlocin i kazna", "Fjodor Dostojevski", 1866),
    ("BK-ABC", "Ana Karenjina", "Lav Tolstoj", 1877),
    ("BK-108", "1984", "George Orwell", 1949)
]
