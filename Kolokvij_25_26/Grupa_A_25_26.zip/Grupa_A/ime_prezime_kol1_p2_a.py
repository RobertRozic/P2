'''
Grupa A

U datoteci books.py nalazi se lista knjiga.
Svaka knjiga predstavljena je kao tuple oblika:

    (sifra_knjige, naziv_knjige, autor, godina)

Primjer:
    ("BK-101", "Mali princ", "Antoine de Saint-Exupery", 1943)

Učitavanje podataka:
    Učitaj listu books iz datoteke books.py.

Provjera šifre:
    Šifra knjige mora biti u obliku BK-XXX, gdje su X znamenke.
    Primjer ispravne šifre: BK-101
    Primjer neispravne šifre: B-101, BK-10, BK-ABC

    Ispravnost šifre provjeri pomoću regularnog izraza.

Obrada podataka:
    Izdvoji samo knjige koje imaju ispravnu šifru.

    Napravi set svih autora koji se pojavljuju među ispravnim knjigama.

    Napravi rječnik u kojem je ključ autor, a vrijednost broj njegovih knjiga.

Ispis i zapis rezultata:
    Na ekran ispiši:
        Broj svih knjiga
        Broj knjiga s ispravnom šifrom
        Set autora
        Rječnik s brojem knjiga po autoru

    Iste rezultate upiši u tekstualnu datoteku izvjestaj_knjige.txt.
'''
